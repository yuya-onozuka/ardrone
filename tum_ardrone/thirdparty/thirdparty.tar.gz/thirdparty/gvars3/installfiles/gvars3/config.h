/* gvars3/config.h.  Generated from config.h.in by configure.  */
#ifndef GVARS3_INCLUDE_CONFIG_H
#define GVARS3_INCLUDE_CONFIG_H
#define GVARS3_HAVE_TOON 1
#endif
